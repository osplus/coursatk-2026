
import { CONFIG } from '../config';
import { Subject, Teacher, Course, Lecture, Exam, Question, Announcement, Admin } from '../types';
import * as MockData from '../mockData';

const getDeviceId = (): string => {
  let id = localStorage.getItem('app_device_id');
  if (!id) {
    id = 'dev_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
    localStorage.setItem('app_device_id', id);
  }
  return id;
};

async function supabaseRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${CONFIG.API_BASE_URL}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    'apikey': CONFIG.SUPABASE_ANON_KEY.trim(),
    'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY.trim()}`,
    ...options.headers,
  };

  try {
    // Add cache: 'no-store' default for data fetching to avoid caching stale data if not specified
    const fetchOptions = {
        cache: 'no-store' as RequestCache,
        ...options,
    };
    const response = await fetch(url, { ...fetchOptions, headers });
    
    if (!response.ok) {
      const errorText = await response.text();
      let errorJson: any = {};
      try {
        errorJson = JSON.parse(errorText);
      } catch {
        errorJson = { message: errorText };
      }
      
      const customError = new Error(errorJson.message || `API Error: ${response.status}`);
      (customError as any).code = errorJson.code;
      (customError as any).details = errorJson.details;
      throw customError;
    }

    if (response.status === 204) return [] as any;
    return await response.json();
  } catch (error: any) {
    throw error;
  }
}

const parseSafeJson = (data: any) => {
  if (!data) return null;
  if (typeof data === 'object') return data;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
};

const findVideoUrl = (obj: any): string => {
  if (!obj) return '';
  return obj.video_url || obj.video_id || obj.videoId || obj.videoUrl || obj.url || obj.link || obj.iframe || obj.embed_code || obj.embed_url || '';
};

const mapLecture = (l: any): Lecture => {
  const mock = MockData.lectures.find(ml => ml.id === String(l.id));
  const mainVideoUrl = findVideoUrl(l);
  
  let validDate = l.created_at;

  return {
    id: String(l.id || ''),
    courseId: String(l.course_id || ''),
    title: l.title || 'محاضرة بدون عنوان',
    videoUrl: mainVideoUrl,
    duration: l.duration || '00:00',
    isCompleted: !!l.is_completed,
    description: l.description || '',
    thumbnail: l.thumbnail || mock?.thumbnail || '',
    parts: l.lecture_parts && Array.isArray(l.lecture_parts) && l.lecture_parts.length > 0
      ? l.lecture_parts.map((p: any) => ({ title: p.title || 'جزء بدون عنوان', videoUrl: findVideoUrl(p), duration: p.duration || '00:00' }))
      : (mock?.parts || []),
    pdfs: l.lecture_pdfs && Array.isArray(l.lecture_pdfs) && l.lecture_pdfs.length > 0
      ? l.lecture_pdfs.map((f: any) => ({ title: f.title || 'ملف PDF', url: f.url || '#' }))
      : (mock?.pdfs || []),
    exams: l.lecture_exams && Array.isArray(l.lecture_exams) && l.lecture_exams.length > 0
      ? l.lecture_exams.map((e: any) => ({ id: String(e.exam_id || ''), title: e.title || 'اختبار تقييمي' }))
      : (mock?.exams || []),
    createdAt: validDate
  };
};

export const API = {
  verifyCode: async (code: string) => {
    const deviceId = getDeviceId();
    if (CONFIG.USE_MOCK) {
      const student = MockData.VALID_CODES.find(c => c.code === code);
      if (!student) return { success: false, message: 'الكود غير صحيح' };
      if (student.deviceId && student.deviceId !== deviceId) return { success: false, message: 'الكود مسجل على جهاز آخر' };
      return { success: true, student: { ...student, name: student.studentName, deviceId } };
    }

    try {
      const data = await supabaseRequest<any[]>(`/activation_codes?code=eq.${code.trim()}&select=*`);
      if (data && data.length > 0) {
        const entry = data[0];
        if (entry.device_id && entry.device_id !== deviceId) return { success: false, message: 'هذا الكود مسجل على جهاز آخر بالفعل' };
        
        const updates: any = { device_id: deviceId };
        if (!entry.expiry_date) {
          const d = new Date();
          d.setDate(d.getDate() + (entry.duration_days || 30));
          updates.expiry_date = d.toISOString();
          updates.activated_at = new Date().toISOString();
        }

        await supabaseRequest(`/activation_codes?id=eq.${entry.id}`, {
          method: 'PATCH',
          body: JSON.stringify(updates)
        });

        return { success: true, student: { name: entry.student_name, code: entry.code, expiryDate: updates.expiry_date || entry.expiry_date, deviceId, section: entry.section } };
      }
      return { success: false, message: 'كود التفعيل غير صحيح أو مستخدم' };
    } catch (err: any) { 
      return { success: false, message: err.message || 'خطأ في الاتصال بالسيرفر' }; 
    }
  },

  checkCodeStatus: async (code: string) => {
    if (CONFIG.USE_MOCK) return { valid: true };
    
    try {
      const data = await supabaseRequest<any[]>(`/activation_codes?code=eq.${code.trim()}&select=expiry_date,device_id`);
      
      if (!data || data.length === 0) {
        return { valid: false, reason: 'deleted', message: 'تم حذف الحساب. يرجى مراجعة الإدارة.' };
      }

      const entry = data[0];
      const now = new Date();
      const expiry = new Date(entry.expiry_date);
      const deviceId = getDeviceId();

      if (entry.device_id && entry.device_id !== deviceId) {
         return { valid: false, reason: 'device_mismatch', message: 'تم تسجيل الدخول من جهاز آخر.' };
      }

      if (now > expiry) {
        return { valid: false, reason: 'expired', message: 'عفواً، انتهت صلاحية الكود الخاص بك.' };
      }

      return { valid: true };
    } catch (err) {
      return { valid: true };
    }
  },

  getSubjects: async () => {
    try {
      const data = await supabaseRequest<any[]>('/subjects?select=*&order=id.asc');
      return Array.isArray(data) ? data.map(s => ({ id: String(s.id), name: s.name, image: s.image, lessonsCount: s.lessons_count || 0 })) : [];
    } catch { return []; }
  },

  getLectures: async (courseId: string) => {
    const endpoint = courseId ? `/lectures?course_id=eq.${courseId}&select=*,lecture_parts(*),lecture_pdfs(*),lecture_exams(*)&order=id.asc` : `/lectures?select=*,lecture_parts(*),lecture_pdfs(*),lecture_exams(*)&order=id.asc`;
    try {
      const data = await supabaseRequest<any[]>(endpoint);
      return Array.isArray(data) ? data.map(mapLecture) : [];
    } catch { return []; }
  },

  getRecentLectures: async (limit: number = 10) => {
    try {
      // Removed _t timestamp parameter to prevent API errors. 
      // supabaseRequest now handles cache: 'no-store' by default (or we can assume fetch behavior).
      const data = await supabaseRequest<any[]>(`/lectures?select=*,lecture_parts(*),lecture_pdfs(*),lecture_exams(*)&order=created_at.desc&limit=${limit}`);
      return Array.isArray(data) ? data.map(mapLecture) : [];
    } catch { return []; }
  },

  getLectureById: async (id: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/lectures?id=eq.${id}&select=*,lecture_parts(*),lecture_pdfs(*),lecture_exams(*)`);
      return data && data.length > 0 ? mapLecture(data[0]) : null;
    } catch { return null; }
  },

  getAdmins: async () => {
    try {
      const data = await supabaseRequest<any[]>('/admins?select=*&order=id.asc');
      return Array.isArray(data) ? data.map(a => ({
        id: String(a.id),
        name: a.name,
        telegram_username: a.telegram_username,
        avatar_url: a.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(a.name)}&background=0088cc&color=fff`,
        role: a.role || 'مسؤول'
      })) : MockData.admins;
    } catch {
      return MockData.admins;
    }
  },

  getAnnouncements: async () => {
    try {
      // Removed _t timestamp parameter to fix "failed to parse filter" error
      const data = await supabaseRequest<any[]>(`/announcements?select=*&order=id.desc`);
      
      return Array.isArray(data) ? data.map(a => ({ 
        id: String(a.id), 
        title: a.title || a.text || 'تنبيه إداري', 
        message: a.message || '', 
        date: a.created_at || new Date().toISOString(), 
        type: a.type || 'info', 
        link: a.link 
      })) : [];
    } catch (e) { 
        console.error("Error fetching announcements:", e);
        return []; 
    }
  },

  getTeachers: async (subjectId: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/teachers?subject_id=eq.${subjectId}&select=*`);
      return Array.isArray(data) ? data.map(t => ({ id: String(t.id), name: t.name, avatar: t.avatar, rating: Number(t.rating) || 5, subjectId: String(t.subject_id), specialty: t.specialty || 'معلم خبير' })) : [];
    } catch { return []; }
  },
  
  getTeacherById: async (id: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/teachers?id=eq.${id}&select=*`);
      if (data && data.length > 0) {
        const t = data[0];
        return {
          id: String(t.id),
          name: t.name,
          avatar: t.avatar,
          rating: Number(t.rating) || 5,
          subjectId: String(t.subject_id),
          specialty: t.specialty || 'معلم خبير'
        } as Teacher;
      }
      return null;
    } catch { return null; }
  },

  getCourses: async (teacherId: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/courses?teacher_id=eq.${teacherId}&select=*`);
      return Array.isArray(data) ? data.map(c => ({ id: String(c.id), title: c.title, thumbnail: c.thumbnail, lectureCount: Number(c.lecture_count) || 0, teacherId: String(c.teacher_id), duration: c.duration || 'غير محدد' })) : [];
    } catch { return []; }
  },

  getCourseById: async (id: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/courses?id=eq.${id}&select=*`);
      if (data && data.length > 0) {
        const c = data[0];
        return {
           id: String(c.id),
           title: c.title,
           thumbnail: c.thumbnail,
           lectureCount: Number(c.lecture_count) || 0,
           teacherId: String(c.teacher_id),
           duration: c.duration || 'غير محدد'
        } as Course;
      }
      return null;
    } catch { return null; }
  },

  getExam: async (id: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/exams?id=eq.${id}&select=*`);
      return data && data.length > 0 ? data[0] : null;
    } catch { return null; }
  },

  getQuestions: async (examId: string) => {
    try {
      const data = await supabaseRequest<any[]>(`/questions?exam_id=eq.${examId}&select=*,option_a,option_b,option_c,option_d&order=id.asc`);
      
      return Array.isArray(data) ? data.map(q => {
        let options: string[] = [];
        
        const rawOptions = [q.option_a, q.option_b, q.option_c, q.option_d, q.option_e];
        
        const individualOptions = rawOptions
            .filter(opt => opt !== null && opt !== undefined && String(opt).trim() !== '')
            .map(opt => String(opt).replace(/^"|"$/g, ''));

        if (individualOptions.length > 0) {
            options = individualOptions;
        } 
        else if (q.options) {
             options = parseSafeJson(q.options) || [];
        }

        let correctIndex = 0;
        if (q.correct_answer !== undefined && q.correct_answer !== null) {
            const val = Number(q.correct_answer);
            correctIndex = val > 0 ? val - 1 : 0;
        }

        return { 
            id: String(q.id), 
            examId: String(q.exam_id), 
            text: q.text, 
            image: q.image_url || q.image, 
            options: options, 
            correctAnswer: correctIndex
        };
      }) : [];
    } catch { return []; }
  }
};
