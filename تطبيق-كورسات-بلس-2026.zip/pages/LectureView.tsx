
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { API } from '../services/api';
import { Lecture } from '../types';

type TabType = 'parts' | 'files' | 'exams';

const LectureView: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const playerContainerRef = useRef<HTMLDivElement>(null);
  
  const [lecture, setLecture] = useState<Lecture | null>(null);
  const [activePart, setActivePart] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>('parts');
  const [studentData, setStudentData] = useState<any>(null);

  useEffect(() => {
    const savedData = localStorage.getItem('app_student_data');
    if (savedData) {
      try {
        setStudentData(JSON.parse(savedData));
      } catch (e) {
        console.error("Failed to load student data for watermark");
      }
    }

    const fetch = async () => {
      if (!id) return;
      setIsLoading(true);
      try {
        const data = await API.getLectureById(id);
        if (data) setLecture(data);
      } catch (err) {
        console.error("Error fetching lecture:", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetch();
  }, [id]);

  const handleBack = () => {
    // التوجيه الصريح لقائمة محاضرات الكورس الحالي
    if (lecture?.courseId) {
      navigate(`/course/${lecture.courseId}/lectures`);
    } else if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/', { replace: true });
    }
  };

  const activeVideoUrl = lecture?.parts?.[activePart]?.videoUrl || lecture?.videoUrl || '';

  const getEmbedUrl = (urlString: string) => {
    if (!urlString) return '';
    let url = urlString.trim();
    if (url.startsWith('<')) {
        const srcMatch = url.match(/src\s*=\s*(["'])(.*?)\1/);
        if (srcMatch && srcMatch[2]) url = srcMatch[2];
    }
    if (url.includes('iframe.mediadelivery.net')) {
      if (!url.includes('autoplay=')) return url.includes('?') ? `${url}&autoplay=true` : `${url}?autoplay=true`;
      return url;
    }
    const ytMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([^&]{11})/);
    if (ytMatch) return `https://www.youtube.com/embed/${ytMatch[1]}?autoplay=1&rel=0`;
    return url;
  };

  const isIframe = (urlString: string) => {
    if (!urlString) return false;
    const url = urlString.trim();
    if (url.startsWith('<') && url.includes('<iframe')) return true;
    return url.includes('youtube') || url.includes('youtu.be') || url.includes('streamable') || url.includes('vimeo') || url.includes('jumpshare') || url.includes('drive.google.com') || url.includes('iframe.mediadelivery.net') || !url.match(/\.(mp4|webm|ogg|mov|m4v)$/i);
  };

  const toggleFullScreen = () => {
    if (playerContainerRef.current) {
      if (!document.fullscreenElement) {
        playerContainerRef.current.requestFullscreen().catch(err => {
          console.error(`Error attempting to enable full-screen mode: ${err.message}`);
        });
      } else {
        document.exitFullscreen();
      }
    }
  };

  if (isLoading) return (
    <div className="fixed inset-0 bg-slate-50 dark:bg-[#020617] flex items-center justify-center z-[9999]">
      <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#020617] text-slate-900 dark:text-white pb-40 font-['Tajawal'] overflow-x-hidden relative transition-colors duration-500" dir="rtl">
      
      {/* Dynamic Background Ambience */}
      <div className="fixed inset-0 pointer-events-none">
         <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/5 dark:bg-blue-600/10 blur-[150px] rounded-full"></div>
         <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-600/5 dark:bg-purple-600/10 blur-[150px] rounded-full"></div>
      </div>

      {/* Adaptive Glass Header */}
      <div className="px-4 py-4 flex items-center gap-4 sticky top-0 z-[100] bg-white/80 dark:bg-[#020617]/80 backdrop-blur-xl border-b border-slate-200 dark:border-white/5 transition-colors">
        <button 
          onClick={handleBack} 
          className="w-10 h-10 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 rounded-xl flex items-center justify-center active:scale-95 transition-all border border-slate-200 dark:border-white/5 shadow-sm cursor-pointer relative z-[110]"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-600 dark:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
          </svg>
        </button>
        <h1 className="text-sm font-bold truncate flex-1 text-slate-700 dark:text-slate-200">{lecture?.title}</h1>
        <button 
          onClick={toggleFullScreen}
          className="w-10 h-10 bg-blue-600/10 dark:bg-blue-600/20 hover:bg-blue-600/20 dark:hover:bg-blue-600/40 rounded-xl flex items-center justify-center transition-all border border-blue-500/20 dark:border-blue-500/30"
          title="عرض بملء الشاشة مع الحماية"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
          </svg>
        </button>
      </div>

      {/* Cinematic Video Player Container */}
      <div ref={playerContainerRef} className="relative w-full z-50 group bg-black">
        <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-b-[2rem] opacity-10 dark:opacity-20 blur-xl group-fullscreen:hidden"></div>
        
        <div className="relative w-full aspect-video bg-black shadow-2xl overflow-hidden border-b border-white/10">
            {/* Super Elevated Watermark Layer */}
            <div className="absolute inset-0 z-[2147483647] pointer-events-none overflow-hidden select-none">
                <div className="animate-watermark opacity-[0.35] md:opacity-[0.45] text-amber-400 text-[10px] md:text-sm font-black rotate-[-12deg] whitespace-nowrap bg-black/70 px-6 py-3 rounded-full backdrop-blur-md border border-amber-500/30 shadow-[0_0_25px_rgba(245,158,11,0.4)] transition-all">
                    {studentData ? `${studentData.name} • ${studentData.code}` : 'Korsat Plus • 2026'}
                </div>
            </div>

            {activeVideoUrl ? (
            isIframe(activeVideoUrl) ? (
                <iframe 
                key={activeVideoUrl}
                src={getEmbedUrl(activeVideoUrl)}
                className="w-full h-full pointer-events-auto relative z-10"
                frameBorder="0"
                allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;"
                allowFullScreen
                loading="lazy"
                title="Video Player"
                />
            ) : (
                <video 
                key={activeVideoUrl}
                src={activeVideoUrl}
                className="w-full h-full pointer-events-auto relative z-10"
                controls
                playsInline
                autoPlay
                poster={lecture?.thumbnail}
                controlsList="nodownload"
                />
            )
            ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900/50 backdrop-blur-sm text-slate-500 gap-4">
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center animate-pulse">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                </div>
                <p className="font-bold text-xs text-white">لا يوجد فيديو متاح حالياً</p>
            </div>
            )}
        </div>
      </div>

      {/* Adaptive Tabs */}
      <div className="px-4 mt-8 relative z-40">
        <div className="bg-white dark:bg-white/5 p-1.5 rounded-[2rem] flex gap-1 border border-slate-200 dark:border-white/5 backdrop-blur-md shadow-lg dark:shadow-xl transition-colors">
           {(['parts', 'files', 'exams'] as TabType[]).map((tabId) => (
             <button 
               key={tabId}
               onClick={() => setActiveTab(tabId)}
               className={`flex-1 py-3.5 rounded-[1.8rem] text-[10px] font-black uppercase transition-all duration-300 flex items-center justify-center gap-2 relative overflow-hidden
                 ${activeTab === tabId ? 'text-white shadow-lg' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5'}
               `}
             >
               {activeTab === tabId && (
                   <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600"></div>
               )}
               <span className="relative z-10 flex items-center gap-2">
                   {tabId === 'parts' && <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" /></svg>}
                   {tabId === 'files' && <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" /></svg>}
                   {tabId === 'exams' && <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>}
                   {tabId === 'parts' ? 'المحتوى' : tabId === 'files' ? 'المرفقات' : 'الاختبارات'}
               </span>
             </button>
           ))}
        </div>
      </div>

      {/* Adaptive List Content */}
      <div className="px-4 mt-6 space-y-3 relative z-40 pb-10">
        {activeTab === 'parts' && lecture?.parts?.map((part, idx) => (
          <button 
            key={idx}
            onClick={() => { setActivePart(idx); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            className={`w-full p-4 rounded-[2rem] border transition-all duration-300 flex items-center gap-4 text-right group relative overflow-hidden
              ${activePart === idx 
                ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500/50 shadow-md dark:shadow-[0_0_30px_-10px_rgba(59,130,246,0.5)]' 
                : 'bg-white dark:bg-white/5 border-slate-200 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/10'}
            `}
          >
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm transition-all duration-300 shrink-0 shadow-inner
              ${activePart === idx ? 'bg-blue-600 text-white scale-110' : 'bg-slate-100 dark:bg-white/5 text-slate-500'}`}>
              {activePart === idx ? <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 animate-pulse" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 001-1.664l-3-2z" clipRule="evenodd" /></svg> : (idx + 1).toString().padStart(2, '0')}
            </div>
            <div className="flex-1 min-w-0 z-10">
              <span className={`block font-bold text-sm mb-1 truncate transition-colors ${activePart === idx ? 'text-blue-600 dark:text-blue-300' : 'text-slate-700 dark:text-slate-200'}`}>{part.title}</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md inline-block ${activePart === idx ? 'bg-blue-500/10 text-blue-600' : 'bg-slate-200/50 dark:bg-black/20 text-slate-500'}`}>{part.duration}</span>
            </div>
          </button>
        ))}

        {activeTab === 'files' && lecture?.pdfs?.map((pdf, idx) => (
          <div 
            key={idx}
            onClick={() => navigate('/pdf', { state: { url: pdf.url, title: pdf.title, returnPath: `/lecture/${id}` } })}
            className="w-full p-5 bg-white dark:bg-white/5 rounded-[2rem] border border-slate-200 dark:border-white/5 flex items-center gap-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-white/10 transition-all group hover:translate-x-[-5px] shadow-sm"
          >
            <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-xl text-red-500 group-hover:scale-110 transition-transform">📄</div>
            <div className="flex-1">
              <h4 className="font-bold text-sm text-slate-800 dark:text-white mb-1 group-hover:text-red-500 transition-colors">{pdf.title}</h4>
              <p className="text-[10px] text-slate-500">انقر للعرض</p>
            </div>
          </div>
        ))}

        {activeTab === 'exams' && lecture?.exams?.map((exam, idx) => (
          <div 
            key={idx}
            onClick={() => navigate(`/quiz/${exam.id}`)}
            className="w-full p-5 bg-white dark:bg-white/5 rounded-[2rem] border border-slate-200 dark:border-white/5 flex items-center gap-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-white/10 transition-all group hover:translate-x-[-5px] shadow-sm"
          >
            <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center text-xl text-yellow-600 dark:text-yellow-500 group-hover:scale-110 transition-transform">📝</div>
            <div className="flex-1">
              <h4 className="font-bold text-sm text-slate-800 dark:text-white mb-1 group-hover:text-yellow-600 dark:group-hover:text-yellow-400 transition-colors">{exam.title}</h4>
              <p className="text-[10px] text-slate-500">اختبار تقييمي</p>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes watermarkMove {
            0% { top: 15%; left: 15%; transform: rotate(-12deg); }
            25% { top: 75%; left: 75%; transform: rotate(-5deg); }
            50% { top: 85%; left: 20%; transform: rotate(5deg); }
            75% { top: 25%; left: 80%; transform: rotate(-8deg); }
            100% { top: 15%; left: 15%; transform: rotate(-12deg); }
        }
        .animate-watermark {
            animation: watermarkMove 15s infinite linear alternate;
            position: absolute;
            pointer-events: none;
            z-index: 2147483647; 
        }
        :fullscreen .animate-watermark {
            font-size: 2.2rem;
            padding: 1.5rem 2.5rem;
            opacity: 0.55;
            background-color: rgba(0,0,0,0.85);
        }
        ::backdrop {
            background-color: black;
        }
      `}</style>
    </div>
  );
};

export default LectureView;
