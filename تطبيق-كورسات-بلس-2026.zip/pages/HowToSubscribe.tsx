
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API } from '../services/api';
import { Admin } from '../types';

const HowToSubscribe: React.FC = () => {
  const navigate = useNavigate();
  const [isLoaded, setIsLoaded] = useState(false);
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [isLoadingAdmins, setIsLoadingAdmins] = useState(true);

  useEffect(() => {
    setIsLoaded(true);
    const fetchAdmins = async () => {
      try {
        const data = await API.getAdmins();
        setAdmins(data);
      } catch (err) {
        console.error("Failed to fetch admins:", err);
      } finally {
        setIsLoadingAdmins(false);
      }
    };
    fetchAdmins();
  }, []);

  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/login');
    }
  };

  const sections = [
    {
      title: '📦 ماذا يشمل الاشتراك؟',
      content: [
        'وصول كامل لكل المحتوى التعليمي',
        'فيديوهات الشرح + المذكرات',
        'اختبارات وتدريبات مستمرة',
        'تحديثات تلقائية طول فترة الاشتراك'
      ],
      icon: '✨'
    },
    {
      title: '💰 قيمة الاشتراك',
      content: [
        'اشتراك شهري مرن بسعر 100 جنية فقط',
        'يشمل كل الخدمات بدون أي رسوم خفية'
      ],
      icon: '💵'
    },
    {
      title: '🧭 طريقة الاشتراك',
      content: [
        'اختر الخطة اللي تناسبك.',
        'تواصل مع أحد مسؤولي الاشتراك المعتمدين.',
        'أرسل بياناتك الأساسية (الاسم – الصف – وسيلة الدفع).',
        'بعد إتمام الدفع، يتم تفعيل حسابك وإرسال بيانات الدخول فورًا.'
      ],
      icon: '🚀'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#020617] text-slate-900 dark:text-white pb-20 font-['Tajawal'] overflow-x-hidden relative transition-colors duration-500" dir="rtl">
      
      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[800px] h-[800px] bg-blue-600/10 dark:bg-blue-600/20 blur-[150px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-purple-600/10 dark:bg-purple-600/20 blur-[150px] rounded-full" style={{ animationDelay: '3s' }}></div>
      </div>

      <div className="relative z-10 px-6 pt-12 max-w-2xl mx-auto">
        
        {/* Top Header */}
        <div className={`text-center mb-12 transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-10'}`}>
           <button 
             onClick={handleBack}
             className="w-12 h-12 bg-white dark:bg-white/5 rounded-2xl flex items-center justify-center border border-slate-200 dark:border-white/10 shadow-lg mb-8 mx-auto hover:scale-110 transition-transform active:scale-95 cursor-pointer relative z-50"
           >
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
             </svg>
           </button>
           <h1 className="text-4xl font-black mb-4">🔔 محتار تشترك إزاي؟</h1>
           <p className="text-slate-500 dark:text-slate-400 font-bold">كل اللي محتاجه علشان تبدأ رحلتك التعليمية موجود هنا 👇</p>
        </div>

        {/* Benefits Cards */}
        <div className="grid grid-cols-1 gap-6 mb-12">
          {sections.map((section, idx) => (
            <div 
              key={idx}
              className={`glass-card p-8 rounded-[3rem] border border-slate-200 dark:border-white/10 shadow-xl transition-all duration-700 ${isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'}`}
              style={{ transitionDelay: `${idx * 200}ms` }}
            >
              <div className="flex items-center gap-4 mb-4">
                <span className="text-3xl">{section.icon}</span>
                <h2 className="text-xl font-black text-slate-800 dark:text-blue-400">{section.title}</h2>
              </div>
              <ul className="space-y-3">
                {section.content.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-slate-600 dark:text-slate-300 font-bold text-sm">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 shrink-0"></div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Important Warning */}
        <div className={`mb-12 p-6 bg-rose-500/10 border border-rose-500/20 rounded-[2.5rem] transition-all duration-1000 ${isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`} style={{ transitionDelay: '800ms' }}>
           <div className="flex gap-4 items-center mb-2">
             <span className="text-2xl">⚠️</span>
             <h3 className="font-black text-rose-600 dark:text-rose-400">تنبيه مهم</h3>
           </div>
           <p className="text-rose-700/80 dark:text-rose-300/80 text-xs font-bold leading-relaxed">
             التعامل يتم فقط من خلال الادمن المعتمدين داخل المنصة. أي تعامل خارج المنصة الرسمية لا تتحمل المنصة مسؤوليته.
           </p>
        </div>

        {/* Admin Selection Area */}
        <div className={`transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{ transitionDelay: '1000ms' }}>
          <div className="text-center mb-8">
             <h3 className="font-black text-blue-600 dark:text-blue-400 text-2xl mb-2">👤 اختار أدمن للاشتراك</h3>
             <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold tracking-widest uppercase">تواصل مباشر عبر تليجرام</p>
          </div>
          
          {isLoadingAdmins ? (
            <div className="flex flex-col items-center justify-center py-12 gap-4">
              <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-xs font-bold text-slate-400 animate-pulse">جاري جلب قائمة المسؤولين...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {admins.map((admin) => (
                <a 
                  key={admin.id}
                  href={`https://t.me/${admin.telegram_username}`} 
                  target="_blank" 
                  rel="noreferrer" 
                  className="bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 p-6 rounded-[3rem] flex items-center gap-4 hover:bg-slate-100 dark:hover:bg-white/10 transition-all active:scale-95 group shadow-lg hover:shadow-blue-500/10"
                >
                  <div className="relative">
                    <img 
                      src={admin.avatar_url} 
                      alt={admin.name} 
                      className="w-16 h-16 rounded-[1.8rem] object-cover border-2 border-blue-500/20 group-hover:scale-110 transition-transform duration-500" 
                    />
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full border-2 border-white dark:border-[#020617] flex items-center justify-center shadow-lg">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-white" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <h4 className="font-black text-sm text-slate-800 dark:text-white truncate group-hover:text-blue-500 transition-colors">{admin.name}</h4>
                    <p className="text-[10px] text-slate-500 font-bold mt-1 bg-slate-100 dark:bg-black/20 w-fit px-2 py-0.5 rounded-md">أدمن</p>
                  </div>
                  <div className="w-11 h-11 bg-[#0088cc] text-white rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/20 group-hover:rotate-12 transition-transform">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.11.02-1.93 1.23-5.46 3.62-.51.35-.98.52-1.4.51-.46-.01-1.35-.26-2.01-.48-.81-.27-1.45-.42-1.39-.88.03-.24.37-.48 1.02-.73 4-.17 6.67-2.83 8-7.98.3-.13.63-.2.97-.2.34 0 .66.07.95.21.29.14.52.35.66.62.11.21.16.45.14.69z"/>
                    </svg>
                  </div>
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Footer CTA */}
        <div className={`mt-16 text-center transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{ transitionDelay: '1200ms' }}>
          <h2 className="text-2xl font-black mb-6">🚀 جاهز تبدأ؟</h2>
          <button 
            onClick={() => navigate('/login')}
            className="w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white py-6 rounded-[2.5rem] font-black text-xl shadow-2xl hover:scale-[1.02] transition-all active:scale-95 relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
            ابدأ الآن
          </button>
        </div>

      </div>

      <style>{`
        .glass-card {
          background: rgba(255, 255, 255, 0.7);
          backdrop-filter: blur(20px);
        }
        .dark .glass-card {
          background: rgba(15, 23, 42, 0.4);
        }
      `}</style>
    </div>
  );
};

export default HowToSubscribe;
