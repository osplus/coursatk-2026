
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const PdfViewer: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { url, title, returnPath } = location.state as { url: string, title: string, returnPath?: string } || {};

  const handleBack = () => {
    // استخدم الاستبدال (replace: true) لضمان مسح صفحة الـ PDF من تاريخ السجل
    if (returnPath) {
      navigate(returnPath, { replace: true });
    } 
    else if (window.history.length > 1) {
      navigate(-1);
    } 
    else {
      navigate('/', { replace: true });
    }
  };

  if (!url) return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#020617] flex flex-col items-center justify-center text-center p-10 font-['Tajawal']" dir="rtl">
        <p className="text-slate-800 dark:text-white mb-6 font-bold">الرابط غير صالح أو انتهت الجلسة</p>
        <button onClick={() => navigate('/', { replace: true })} className="bg-blue-600 text-white px-8 py-3 rounded-2xl font-black shadow-lg hover:bg-blue-700 transition-colors cursor-pointer">عودة للرئيسية</button>
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-slate-50 dark:bg-[#020617] font-['Tajawal']" dir="rtl">
      <div className="flex-none px-6 py-4 flex items-center justify-between border-b border-slate-200 dark:border-white/10 bg-white dark:bg-[#0f172a] shadow-sm z-[100] relative">
        <button 
           type="button"
           onClick={handleBack} 
           className="w-12 h-12 bg-slate-100 dark:bg-white/10 rounded-2xl flex items-center justify-center border border-slate-200 dark:border-white/10 hover:bg-slate-200 dark:hover:bg-white/20 transition-all cursor-pointer active:scale-95 text-slate-600 dark:text-white relative z-[110]"
           aria-label="رجوع"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
            </svg>
        </button>
        <h1 className="text-base font-black text-slate-800 dark:text-white truncate mx-4 flex-1 text-center">{title || 'عرض المذكرة'}</h1>
        <div className="w-12"></div>
      </div>
      <div className="flex-1 bg-slate-200 dark:bg-slate-900 relative w-full overflow-hidden">
        <iframe 
          src={`https://docs.google.com/viewer?url=${encodeURIComponent(url)}&embedded=true`} 
          className="w-full h-full border-0"
          title="PDF Viewer"
          allowFullScreen
        />
      </div>
    </div>
  );
};

export default PdfViewer;
