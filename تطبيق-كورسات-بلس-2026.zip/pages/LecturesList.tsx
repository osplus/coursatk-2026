
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { API } from '../services/api';
import BottomNav from '../components/BottomNav';
import { Lecture, Course } from '../types';

const LecturesList: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [course, setCourse] = useState<Course | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      if (!id) return;
      setIsLoading(true);
      try {
        const [lecturesData, courseData] = await Promise.all([
             API.getLectures(id),
             API.getCourseById(id)
        ]);
        setLectures(lecturesData);
        setCourse(courseData);
      } catch (err) { console.error(err); } finally { setIsLoading(false); }
    };
    fetch();
  }, [id]);

  const handleBack = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // العودة الصريحة لقائمة كورسات المدرس إذا كانت بيانات الكورس متاحة
    if (course?.teacherId) {
        navigate(`/teacher/${course.teacherId}/courses`);
    } else if (window.history.length > 1) {
        navigate(-1);
    } else {
        navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#020617] pb-56 relative overflow-x-hidden transition-colors duration-300" dir="rtl">
      {/* التأكد من أن الخلفية لا تعيق الضغط */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-blue-600/10 blur-[130px] rounded-full"></div>
      </div>

      <div className="px-6 pt-16 mb-8 relative z-[500] flex items-center justify-between">
         <div className="animate__animated animate__fadeInRight">
            <h1 className="text-3xl font-black text-slate-800 dark:text-white mb-1">محتوى <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600">الكورس</span></h1>
            <p className="text-slate-500 text-[10px] font-bold tracking-widest uppercase">تصفح المحاضرات المتاحة</p>
         </div>
         <button 
           type="button"
           onClick={handleBack} 
           className="w-14 h-14 glass-card rounded-2xl flex items-center justify-center border border-slate-200 dark:border-white/10 shadow-xl active:scale-90 transition-all group hover:bg-white dark:hover:bg-white/10 cursor-pointer relative z-[600]"
         >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-slate-500 dark:text-white group-hover:text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
            </svg>
         </button>
      </div>

      <div className="px-6 space-y-8 relative z-10">
        {isLoading ? (
          [1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-slate-200 dark:bg-white/5 rounded-[3rem] animate-pulse"></div>
          ))
        ) : lectures.length > 0 ? (
          lectures.map((lecture, idx) => (
            <div key={lecture.id} className="glass-card rounded-[3rem] p-5 border border-slate-200 dark:border-white/5 shadow-xl animate-card group hover:border-blue-500/20 transition-all duration-500" style={{ animationDelay: `${0.3 + (idx * 0.15)}s` }}>
              <div onClick={() => navigate(`/lecture/${lecture.id}`)} className="relative aspect-video rounded-[2.2rem] overflow-hidden mb-6 cursor-pointer group/player shadow-2xl">
                <img src={lecture.thumbnail} className="w-full h-full object-cover group-hover/player:scale-110 transition-transform duration-1000" alt={lecture.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-[#020617]/80 via-transparent to-transparent"></div>
                <div className="absolute top-4 right-4 bg-black/40 backdrop-blur-xl px-4 py-1.5 rounded-xl border border-white/20 flex items-center gap-2">
                   <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
                   <span className="text-[10px] font-black text-white/90">{lecture.duration}</span>
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white/10 backdrop-blur-2xl rounded-full flex items-center justify-center border border-white/20 shadow-2xl group-hover/player:scale-125 transition-transform duration-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white fill-current" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 001-1.664l-3-2z" /></svg>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between px-2">
                <div className="flex-1 text-right">
                  <h3 className="text-xl font-black text-slate-800 dark:text-white mb-1 group-hover:text-blue-500 transition-colors line-clamp-1">{lecture.title}</h3>
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">محاضرة تفاعلية</span>
                </div>
                <button onClick={() => navigate(`/lecture/${lecture.id}`)} className="relative px-8 py-3.5 bg-slate-100 dark:bg-[#1e293b] rounded-2xl overflow-hidden group/btn shadow-inner">
                  <span className="relative z-10 text-slate-700 dark:text-white font-black text-xs group-hover/btn:text-white">دخول الآن</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-0 group-hover/btn:opacity-100 transition-opacity"></div>
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-20 opacity-40">
            <span className="text-5xl block mb-4">📂</span>
            <p className="font-black text-slate-500">لايوجد محاضرات نزلت لسه</p>
          </div>
        )}
      </div>
      <BottomNav />
    </div>
  );
};

export default LecturesList;
