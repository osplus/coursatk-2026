
import React, { useState, useEffect } from 'react';
import BottomNav from '../components/BottomNav';

interface ProfileProps {
  onLogout?: () => void;
  student?: any;
}

const Profile: React.FC<ProfileProps> = ({ onLogout, student }) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const copyToClipboard = () => {
    if (student?.code) {
      navigator.clipboard.writeText(student.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return 'غير متوفر';
    try {
      return new Date(dateStr).toLocaleDateString('ar-EG', { 
        day: 'numeric', month: 'long', year: 'numeric' 
      });
    } catch (e) {
      return 'غير متوفر';
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#020617] pb-44 relative overflow-hidden font-['Tajawal'] text-slate-900 dark:text-white selection:bg-violet-500/30 transition-colors duration-500" dir="rtl">
      
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[120vw] h-[60vh] bg-gradient-to-br from-violet-600/10 dark:from-violet-600/20 via-transparent to-transparent blur-[120px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[120vw] h-[60vh] bg-gradient-to-tl from-cyan-600/5 dark:from-cyan-600/15 via-transparent to-transparent blur-[120px] rounded-full" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className={`relative z-10 px-6 pt-14 transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'}`}>
        
        <header className="flex flex-col items-center mb-10">
            <div className="relative mb-8 group">
                <div className="absolute -inset-10 bg-violet-600/5 dark:bg-violet-600/10 rounded-full blur-[80px] group-hover:bg-violet-600/10 transition-all duration-1000 animate-pulse"></div>
                <div className="absolute -inset-1 bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-cyan-500 rounded-[3rem] opacity-20 dark:opacity-40 blur-sm group-hover:opacity-100 transition-opacity duration-700"></div>
                
                <div className="relative w-32 h-32 bg-slate-50 dark:bg-[#0f172a] rounded-[2.8rem] flex items-center justify-center border border-slate-200 dark:border-white/20 shadow-2xl overflow-hidden transition-colors duration-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-violet-500 dark:text-violet-400 drop-shadow-md animate-float" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-violet-500 to-transparent opacity-40 dark:opacity-60"></div>
                </div>
            </div>
            
            <h1 className="text-3xl font-black text-slate-800 dark:text-white mb-2 tracking-tight text-center bg-clip-text text-transparent bg-gradient-to-b from-slate-900 to-slate-500 dark:from-white dark:to-slate-400">
                {student?.name || 'طالب متميز'}
            </h1>
            
            <div className="flex items-center gap-2 px-6 py-2 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl shadow-sm dark:shadow-xl transition-colors">
                <span className="w-2 h-2 bg-cyan-500 rounded-full animate-ping"></span>
                <p className="text-[10px] font-black text-cyan-600 dark:text-cyan-400 uppercase tracking-[0.3em]">{student?.section || 'نظام النخبة التعليمي'}</p>
            </div>
        </header>

        <div className="glass-card rounded-[3.5rem] p-8 border border-slate-200 dark:border-white/10 shadow-2xl mb-8 relative overflow-hidden group">
            <div className="relative z-10">
                {/* تم مسح كلمة كود طالب هنا بناءً على الطلب */}
                <div className="bg-slate-50 dark:bg-black/40 backdrop-blur-md p-6 rounded-[2rem] border border-slate-200 dark:border-white/5 mb-8 flex items-center justify-between transition-all duration-500">
                    <span className="text-3xl font-black tracking-[0.5em] text-slate-900 dark:text-white drop-shadow-sm">
                        {student?.code || '•••• •••'}
                    </span>
                    <button 
                        onClick={copyToClipboard}
                        className="w-12 h-12 bg-violet-600/10 dark:bg-violet-600/20 hover:bg-violet-600 text-violet-600 dark:text-violet-400 hover:text-white rounded-2xl flex items-center justify-center transition-all active:scale-90 shadow-sm"
                    >
                        {copied ? '✓' : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>}
                    </button>
                </div>

                <div className="relative group/expiry">
                    <div className="absolute -inset-4 bg-blue-500/5 dark:bg-blue-600/20 rounded-[2.5rem] blur-2xl opacity-100 transition-opacity duration-700"></div>
                    <div className="relative flex flex-col items-center justify-center py-8 px-6 bg-white dark:bg-gradient-to-b dark:from-[#1e293b] dark:to-[#0f172a] rounded-[2.5rem] border border-slate-200 dark:border-blue-500/20 shadow-2xl transition-all duration-500">
                        <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mb-4 border border-blue-500/10 shadow-[0_0_15px_rgba(59,130,246,0.1)]">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-500 dark:text-blue-400 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <span className="text-[10px] font-black text-slate-500 dark:text-blue-400 uppercase tracking-[0.5em] mb-2 text-center">صلاحية الحساب حتى تاريخ</span>
                        <div className="relative">
                            <span className="text-3xl font-black text-slate-900 dark:text-white tracking-wider block text-center drop-shadow-sm">
                                {formatDate(student?.expiryDate)}
                            </span>
                            <div className="h-1.5 w-24 bg-gradient-to-r from-transparent via-blue-500 to-transparent mx-auto mt-3 rounded-full opacity-60"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="space-y-4">
            <button 
                onClick={() => navigator.share && navigator.share({ title: 'كورسات بلس', url: window.location.origin })}
                className="group relative w-full h-20 bg-slate-100 dark:bg-gradient-to-r dark:from-violet-600/10 dark:to-indigo-600/10 hover:bg-slate-200 dark:hover:from-violet-600/20 dark:hover:to-indigo-600/20 border border-slate-200 dark:border-violet-500/20 text-slate-800 dark:text-white font-black rounded-[2rem] flex items-center justify-between px-8 transition-all active:scale-95"
            >
                <div className="flex items-center gap-5">
                    <div className="w-11 h-11 bg-violet-500/10 rounded-2xl flex items-center justify-center text-violet-600 dark:text-violet-400 group-hover:scale-110 transition-all">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 100-6 3 3 0 000 6zm0 12a3 3 0 100-6 3 3 0 000 6z" /></svg>
                    </div>
                    <span className="text-sm tracking-wide">ادعُ أصدقاءك للمنصة</span>
                </div>
            </button>

            <button 
                onClick={() => setShowConfirm(true)}
                className="w-full h-20 bg-rose-50 dark:bg-rose-500/5 hover:bg-rose-100 dark:hover:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 text-rose-600 dark:text-rose-500 font-black rounded-[2rem] flex items-center justify-between px-8 transition-all active:scale-95"
            >
                <div className="flex items-center gap-5">
                    <div className="w-11 h-11 bg-rose-500/10 rounded-2xl flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                    </div>
                    <span className="text-sm tracking-wide">تسجيل الخروج</span>
                </div>
            </button>
        </div>

        <footer className="mt-14 flex flex-col items-center opacity-40 dark:opacity-20">
            <div className="flex items-center gap-4 mb-2">
                <div className="h-px w-8 bg-slate-400 dark:bg-white"></div>
                <span className="text-[8px] text-slate-600 dark:text-white font-black tracking-[0.8em] uppercase">Hyper Platform v4.0</span>
                <div className="h-px w-8 bg-slate-400 dark:bg-white"></div>
            </div>
        </footer>
      </div>

      {showConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-8 bg-black/60 dark:bg-black/95 backdrop-blur-3xl animate-fadeIn">
          <div className="bg-white dark:bg-[#0f172a] w-full max-w-sm rounded-[3.5rem] p-12 border border-slate-200 dark:border-white/10 animate-scaleUp text-center shadow-2xl">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-4">هل أنت متأكد؟</h3>
            <p className="text-slate-500 font-bold mb-10 text-[11px] leading-relaxed px-4">ستحتاج لتفعيل الكود الخاص بك عند محاولة الدخول مرة أخرى.</p>
            <div className="flex flex-col gap-4">
              <button onClick={() => onLogout?.()} className="w-full bg-rose-600 hover:bg-rose-700 text-white py-5 rounded-[1.5rem] font-black shadow-lg shadow-rose-900/20 active:scale-95 transition-all">خروج نهائي</button>
              <button onClick={() => setShowConfirm(false)} className="w-full bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 py-5 rounded-[1.5rem] font-bold border border-slate-200 dark:border-white/5 active:scale-95 transition-all">الرجوع</button>
            </div>
          </div>
        </div>
      )}

      {copied && (
        <div className="fixed bottom-40 left-1/2 -translate-x-1/2 z-[200] bg-violet-600 text-white px-10 py-4 rounded-3xl font-black text-xs shadow-xl animate-bounce">
            ✓ تم النسخ بنجاح
        </div>
      )}

      <BottomNav />
      
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleUp { from { opacity: 0; transform: scale(0.85); } to { opacity: 1; transform: scale(1); } }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out; }
        .animate-scaleUp { animation: scaleUp 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .glass-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(50px);
        }
        .dark .glass-card {
            background: rgba(15, 23, 42, 0.4);
        }
      `}</style>
    </div>
  );
};

export default Profile;
