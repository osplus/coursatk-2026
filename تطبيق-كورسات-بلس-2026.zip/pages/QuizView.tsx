
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { API } from '../services/api';
import { Question, Exam } from '../types';

type QuizState = 'intro' | 'active' | 'result';

const QuizView: React.FC = () => {
  const { examId } = useParams<{ examId: string }>();
  const navigate = useNavigate();
  
  const [viewState, setViewState] = useState<QuizState>('intro');
  const [exam, setExam] = useState<Exam | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [isLoading, setIsLoading] = useState(true);
  
  // Timer State
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const loadQuiz = async () => {
      if (!examId) return;
      try {
        const [examData, questionsData] = await Promise.all([
          API.getExam(examId),
          API.getQuestions(examId)
        ]);
        setExam(examData);
        setQuestions(questionsData);
        if (examData?.durationMinutes) {
          setTimeLeft(examData.durationMinutes * 60);
        } else {
          setTimeLeft(45 * 60); 
        }
      } catch (err) { console.error(err); } finally { setIsLoading(false); }
    };
    loadQuiz();
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [examId]);

  useEffect(() => {
    if (viewState === 'active' && timeLeft === 0) {
      submitExam();
    }
  }, [timeLeft, viewState]);

  const startExam = () => {
    if (!questions || questions.length === 0) return;
    setViewState('active');
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => (prev <= 0 ? 0 : prev - 1));
    }, 1000);
  };

  const submitExam = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setViewState('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectOption = (optionIdx: number) => {
    setUserAnswers({ ...userAnswers, [currentIdx]: optionIdx });
  };

  const jumpToQuestion = (idx: number) => {
    if (idx >= 0 && idx < questions.length) {
      setCurrentIdx(idx);
    }
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach((q, idx) => { if (userAnswers[idx] === q.correctAnswer) correct++; });
    const total = questions.length;
    const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;
    const isPassed = percentage >= (exam?.passingScore || 50);
    return { correct, total, percentage, isPassed };
  };

  const handleBack = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate('/');
  };

  const getOptionLabel = (idx: number) => {
    const labels = ['أ', 'ب', 'ج', 'د', 'هـ', 'و'];
    return labels[idx] || idx + 1;
  };

  const FireConfetti = () => (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
        {[...Array(50)].map((_, i) => (
            <div key={i} className="absolute animate-confetti" style={{
                left: `${Math.random() * 100}%`,
                top: `-10%`,
                backgroundColor: ['#ef4444', '#8b5cf6', '#10b981', '#f472b6', '#c084fc'][Math.floor(Math.random() * 5)],
                width: `${Math.random() * 10 + 5}px`,
                height: `${Math.random() * 10 + 5}px`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${Math.random() * 3 + 2}s`
            }}></div>
        ))}
    </div>
  );

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center">
       <div className="relative glass-card p-6 rounded-full">
         <div className="w-12 h-12 border-4 border-violet-500/30 border-t-violet-500 rounded-full animate-spin"></div>
       </div>
    </div>
  );

  // --- شاشة البداية ---
  if (viewState === 'intro') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 font-['Tajawal'] relative text-white" dir="rtl">
        <button onClick={handleBack} className="absolute top-6 right-6 w-12 h-12 glass-card rounded-2xl flex items-center justify-center shadow-lg hover:scale-105 transition-transform z-[100] cursor-pointer text-white/80 bg-white/5 border-white/10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
        </button>

        <div className="w-full max-w-lg relative z-10 animate__animated animate__zoomIn">
          <div className="glass-card rounded-[3rem] p-10 text-center relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-violet-500"></div>
             
             <div className="w-28 h-28 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-[2rem] mx-auto mb-8 flex items-center justify-center shadow-2xl shadow-violet-500/30 rotate-3 hover:rotate-12 transition-transform duration-500 group relative">
                <div className="absolute inset-0 bg-violet-500/20 blur-xl rounded-[2rem]"></div>
                <span className="text-5xl group-hover:scale-125 transition-transform duration-300 relative z-10">🚀</span>
             </div>
             
             <h1 className="text-3xl font-black text-white mb-4 leading-tight drop-shadow-lg">{exam?.title || 'اختبار تقييمي'}</h1>
             
             <div className="flex justify-center gap-4 mb-8 text-xs font-bold text-slate-200">
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-xl border border-white/10 shadow-inner backdrop-blur-sm">
                   <span className="text-violet-300">⏱️</span>
                   <span>{exam?.durationMinutes || 45} دقيقة</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-xl border border-white/10 shadow-inner backdrop-blur-sm">
                   <span className="text-fuchsia-300">❓</span>
                   <span>{questions.length} أسئلة</span>
                </div>
             </div>

             {questions.length > 0 ? (
                <button onClick={startExam} className="group relative w-full h-16 rounded-2xl overflow-hidden active:scale-95 transition-all shadow-xl shadow-violet-600/30">
                    <div className="absolute inset-0 bg-gradient-to-r from-violet-600 to-fuchsia-600 transition-all duration-300 group-hover:scale-105"></div>
                    <div className="relative flex items-center justify-center gap-3 text-white font-black text-lg tracking-wide">
                        <span>ابدأ التحدي</span>
                    </div>
                </button>
             ) : (
                <div className="bg-red-500/20 text-red-200 p-4 rounded-2xl font-bold text-sm border border-red-500/20 backdrop-blur-sm">
                   عذراً، لا توجد أسئلة متاحة لهذا الاختبار حالياً.
                </div>
             )}
          </div>
        </div>
      </div>
    );
  }

  // --- شاشة النتيجة ---
  if (viewState === 'result') {
    const { score, percentage, isPassed } = { ...calculateScore(), score: calculateScore().correct };
    
    return (
      <div className="min-h-screen flex flex-col p-6 font-['Tajawal'] relative overflow-x-hidden text-white" dir="rtl">
        {isPassed && <FireConfetti />}
        
        <div className="max-w-4xl mx-auto w-full relative z-10 animate__animated animate__fadeInUp">
           {/* Result Header Card */}
           <div className="glass-card rounded-[3rem] p-8 text-center shadow-2xl mb-8 overflow-hidden relative border-t border-white/20">
              <div className={`absolute top-0 left-0 w-full h-1 ${isPassed ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
              
              <div className="mb-6 relative">
                <div className={`w-40 h-40 mx-auto rounded-full flex items-center justify-center border-8 ${isPassed ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10' : 'border-rose-500/30 text-rose-400 bg-rose-500/10'} shadow-[0_0_50px_rgba(0,0,0,0.5)] backdrop-blur-sm`}>
                    <div className="text-center">
                        <span className="text-6xl font-black block tracking-tighter">{percentage}%</span>
                        <span className="text-[10px] font-bold opacity-70 uppercase tracking-[0.3em]">النتيجة</span>
                    </div>
                </div>
              </div>

              <h2 className="text-4xl font-black text-white mb-2 drop-shadow-md">{isPassed ? 'أداء رائع!' : 'حاول مرة أخرى'}</h2>
              <p className="text-slate-300 font-bold mb-10 text-sm opacity-80">
                {isPassed ? 'أثبت جدارتك، استمر في التقدم.' : 'لا تيأس، كل خطأ هو فرصة للتعلم.'}
              </p>

              <div className="grid grid-cols-3 gap-6 mb-10 max-w-2xl mx-auto">
                 <div className="bg-white/5 p-6 rounded-[2rem] border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors">
                    <div className="text-3xl mb-2">✅</div>
                    <div className="text-2xl font-black text-white">{calculateScore().correct}</div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">صحيحة</div>
                 </div>
                 <div className="bg-white/5 p-6 rounded-[2rem] border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors">
                    <div className="text-3xl mb-2">❌</div>
                    <div className="text-2xl font-black text-white">{questions.length - calculateScore().correct}</div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">خاطئة</div>
                 </div>
                 <div className="bg-white/5 p-6 rounded-[2rem] border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors">
                    <div className="text-3xl mb-2">📊</div>
                    <div className="text-2xl font-black text-white">{questions.length}</div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">المجموع</div>
                 </div>
              </div>

              <button onClick={handleBack} className="w-full max-w-md mx-auto bg-white text-slate-900 py-5 rounded-[2rem] font-black shadow-lg hover:scale-105 active:scale-95 transition-all mb-8">
                  العودة للقائمة الرئيسية
              </button>
           </div>

           {/* Detailed Answers Review */}
           <div className="space-y-6 pb-20">
               <h3 className="text-2xl font-black text-white px-4 border-r-4 border-blue-500">مراجعة الإجابات</h3>
               
               {questions.map((q, idx) => {
                 const userAns = userAnswers[idx];
                 const isCorrect = userAns === q.correctAnswer;
                 
                 return (
                    <div key={idx} className={`glass-card rounded-[2.5rem] p-6 md:p-8 border shadow-xl relative overflow-hidden ${isCorrect ? 'border-emerald-500/20' : 'border-rose-500/20'}`}>
                        {/* Status Icon */}
                        <div className={`absolute top-0 left-0 px-4 py-2 rounded-br-2xl text-[10px] font-black uppercase tracking-widest ${isCorrect ? 'bg-emerald-500 text-emerald-950' : 'bg-rose-500 text-rose-950'}`}>
                           {isCorrect ? 'إجابة صحيحة' : 'إجابة خاطئة'}
                        </div>

                        <div className="mb-6 flex gap-4">
                           <span className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold text-sm shrink-0">{idx + 1}</span>
                           <h4 className="text-lg font-bold text-white leading-relaxed">{q.text}</h4>
                        </div>
                        
                        {q.image && (
                          <div className="mb-6 rounded-2xl overflow-hidden border border-white/10 bg-black/20 w-fit">
                              <img src={q.image} alt="Question" className="max-h-64 object-contain" />
                          </div>
                        )}

                        <div className="space-y-3">
                           {/* User Answer */}
                           <div className={`p-4 rounded-2xl border flex items-center gap-3 ${isCorrect ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-rose-500/10 border-rose-500/30 text-rose-300'}`}>
                              <span className="font-bold text-xs opacity-70">إجابتك:</span>
                              <span className="font-black text-sm">{q.options[userAns] || 'لم يتم الإجابة'}</span>
                              <span className="mr-auto text-lg">{isCorrect ? '✓' : '✗'}</span>
                           </div>

                           {/* Correct Answer (Show only if wrong) */}
                           {!isCorrect && (
                               <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-3">
                                   <span className="font-bold text-xs opacity-70">الإجابة الصحيحة:</span>
                                   <span className="font-black text-sm">{q.options[q.correctAnswer]}</span>
                                   <span className="mr-auto text-lg">✓</span>
                               </div>
                           )}
                        </div>
                    </div>
                 );
               })}
           </div>
        </div>
      </div>
    );
  }

  // --- شاشة الاختبار النشط ---
  const currentQuestion = questions[currentIdx];
  const progress = ((Object.keys(userAnswers).length) / questions.length) * 100;

  return (
    <div className="min-h-screen flex flex-col font-['Tajawal'] overflow-hidden text-white bg-[#0f172a] relative" dir="rtl">
        {/* Header Bar */}
        <header className="h-20 px-6 flex items-center justify-between glass-card border-b border-white/5 relative z-50">
            <button onClick={handleBack} className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </button>
            
            <h1 className="font-bold text-sm md:text-lg text-slate-200 truncate mx-4">{exam?.title}</h1>

            <div className={`px-4 py-2 rounded-xl font-black text-sm border flex items-center gap-2 transition-all duration-500 shadow-lg ${timeLeft < 60 ? 'bg-red-500/20 text-red-400 border-red-500/50 animate-pulse' : 'bg-blue-500/10 text-blue-400 border-blue-500/20'}`}>
                <span className="tabular-nums tracking-widest font-mono text-lg">{formatTime(timeLeft)}</span>
                <span>⏳</span>
            </div>
        </header>

        {/* Main Content Grid */}
        <div className="flex-1 overflow-hidden relative flex flex-col md:flex-row gap-6 p-4 md:p-6 container mx-auto max-w-7xl">
            
            {/* Sidebar (Question Map) - Right on Desktop, Bottom on Mobile */}
            <aside className="order-2 md:order-1 w-full md:w-80 shrink-0 flex flex-col gap-4">
                <div className="glass-card rounded-[2.5rem] p-6 border border-white/10 flex-1 flex flex-col shadow-2xl overflow-hidden">
                    <div className="mb-6 pb-4 border-b border-white/5">
                        <h3 className="font-black text-slate-200 mb-2">خريطة الأسئلة</h3>
                        <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                             <div className="w-2 h-2 rounded-full bg-emerald-500"></div> <span>مجاب عنها</span>
                             <div className="w-2 h-2 rounded-full bg-blue-500 ml-2"></div> <span>الحالي</span>
                             <div className="w-2 h-2 rounded-full bg-slate-600"></div> <span>متبقي</span>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-5 gap-3 content-start overflow-y-auto pr-1 custom-scrollbar" style={{maxHeight: '400px'}}>
                        {questions.map((_, idx) => {
                            const isAnswered = userAnswers[idx] !== undefined;
                            const isCurrent = currentIdx === idx;
                            return (
                                <button
                                    key={idx}
                                    onClick={() => jumpToQuestion(idx)}
                                    className={`aspect-square rounded-2xl flex items-center justify-center font-bold text-sm transition-all duration-300
                                        ${isCurrent 
                                            ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)] scale-110 z-10' 
                                            : isAnswered 
                                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                                                : 'bg-white/5 text-slate-500 hover:bg-white/10'}
                                    `}
                                >
                                    {idx + 1}
                                </button>
                            )
                        })}
                    </div>

                    <div className="mt-auto pt-6 border-t border-white/5 space-y-3">
                         <div className="flex justify-between text-xs font-bold text-slate-400 mb-2">
                             <span>تمت الإجابة</span>
                             <span className="text-emerald-400">{Object.keys(userAnswers).length} / {questions.length}</span>
                         </div>
                         <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                             <div className="h-full bg-emerald-500 transition-all duration-500" style={{width: `${progress}%`}}></div>
                         </div>
                         
                         <button 
                            onClick={submitExam} 
                            className="w-full mt-4 bg-white/10 hover:bg-white/20 text-white py-4 rounded-2xl font-black transition-all border border-white/10 active:scale-95"
                         >
                             تسليم الامتحان
                         </button>
                    </div>
                </div>
            </aside>

            {/* Main Question Area */}
            <main className="order-1 md:order-2 flex-1 flex flex-col h-full overflow-y-auto custom-scrollbar pb-20 md:pb-0">
                
                {/* Navigation Top (Mobile Only) */}
                <div className="md:hidden flex justify-between items-center mb-4 text-xs font-bold text-slate-400">
                    <span>السؤال {currentIdx + 1} من {questions.length}</span>
                </div>

                <div className="w-full max-w-3xl mx-auto space-y-6">
                    {/* Question Card */}
                    <div className="glass-card bg-[#1e293b]/60 rounded-[2.5rem] p-6 md:p-10 border border-white/10 shadow-2xl relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 rounded-bl-[100%] -mr-10 -mt-10 blur-xl"></div>
                        
                        <div className="flex justify-between items-start mb-6 relative z-10">
                            <span className="px-4 py-1.5 rounded-lg bg-blue-500/10 text-blue-400 text-[10px] font-black border border-blue-500/20">
                                سؤال اختيار من متعدد
                            </span>
                            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center font-black text-white shadow-lg">
                                {currentIdx + 1}
                            </div>
                        </div>

                        <h2 className="text-xl md:text-2xl font-bold text-white leading-relaxed mb-6 text-right relative z-10">
                            {currentQuestion?.text}
                        </h2>

                        {currentQuestion?.image && (
                            <div className="rounded-2xl overflow-hidden border border-white/10 shadow-lg mb-6 bg-black/20">
                                <img src={currentQuestion.image} alt="Question" className="w-full h-auto object-contain max-h-[400px]" />
                            </div>
                        )}
                    </div>

                    {/* Options Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {currentQuestion?.options && currentQuestion.options.length > 0 ? (
                            currentQuestion.options.map((option, idx) => {
                                const isSelected = userAnswers[currentIdx] === idx;
                                const label = getOptionLabel(idx);
                                
                                return (
                                    <button
                                        key={idx}
                                        onClick={() => handleSelectOption(idx)}
                                        className={`group relative p-1 rounded-[2rem] transition-all duration-300 active:scale-[0.98]
                                            ${isSelected ? 'bg-gradient-to-r from-purple-600 to-blue-600 shadow-[0_0_20px_rgba(124,58,237,0.4)]' : 'bg-transparent hover:bg-white/5'}
                                        `}
                                    >
                                        <div className={`relative h-full bg-[#1e293b]/80 backdrop-blur-xl rounded-[1.8rem] p-5 flex items-center gap-4 border transition-all
                                            ${isSelected ? 'border-transparent bg-[#1e293b]/40' : 'border-white/10 group-hover:border-white/20'}
                                        `}>
                                            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-lg transition-all shrink-0
                                                ${isSelected 
                                                    ? 'bg-white text-purple-600 shadow-lg scale-110' 
                                                    : 'bg-white/5 text-slate-400 group-hover:bg-white/10 group-hover:text-white'}
                                            `}>
                                                {label}
                                            </div>
                                            <span className={`flex-1 text-right font-bold text-sm md:text-base leading-snug
                                                ${isSelected ? 'text-white' : 'text-slate-300 group-hover:text-white'}
                                            `}>
                                                {option}
                                            </span>
                                            
                                            {/* Selection Indicator */}
                                            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center
                                                ${isSelected ? 'border-purple-400 bg-purple-500/20' : 'border-slate-600'}
                                            `}>
                                                {isSelected && <div className="w-2.5 h-2.5 bg-purple-400 rounded-full"></div>}
                                            </div>
                                        </div>
                                    </button>
                                );
                            })
                        ) : (
                            <div className="col-span-2 text-center py-10 text-slate-500 bg-white/5 rounded-3xl border border-white/5 border-dashed">
                                لا توجد اختيارات متاحة لهذا السؤال
                            </div>
                        )}
                    </div>

                    {/* Navigation Buttons (Desktop Style) */}
                    <div className="flex justify-between gap-4 pt-6">
                        <button 
                            onClick={() => jumpToQuestion(currentIdx - 1)}
                            disabled={currentIdx === 0}
                            className="px-8 py-4 rounded-2xl font-bold bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:hover:bg-white/5 text-slate-300 border border-white/5 transition-all"
                        >
                            السابق
                        </button>
                        <button 
                            onClick={() => jumpToQuestion(currentIdx + 1)}
                            disabled={currentIdx === questions.length - 1}
                            className="px-8 py-4 rounded-2xl font-bold bg-white text-slate-900 hover:bg-slate-200 disabled:opacity-30 disabled:hover:bg-white shadow-lg transition-all"
                        >
                            التالي
                        </button>
                    </div>
                </div>
            </main>
        </div>
        
        <style>{`
            .animate-confetti {
                animation: confetti 4s ease-out forwards;
            }
            @keyframes confetti {
                0% { transform: translateY(0) rotate(0); opacity: 1; }
                100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
            }
            .custom-scrollbar::-webkit-scrollbar {
                width: 4px;
            }
            .custom-scrollbar::-webkit-scrollbar-track {
                background: rgba(255,255,255,0.02);
            }
            .custom-scrollbar::-webkit-scrollbar-thumb {
                background: rgba(255,255,255,0.1);
                border-radius: 10px;
            }
        `}</style>
    </div>
  );
};

export default QuizView;
