
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { API } from '../services/api';

interface LoginProps {
  onLogin: (studentData: any) => void;
  externalError?: string | null;
}

const Login: React.FC<LoginProps> = ({ onLogin, externalError }) => {
  const navigate = useNavigate();
  const [codeParts, setCodeParts] = useState<string[]>(new Array(7).fill(''));
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    // التركيز على الحقل الأول
    if (inputRefs.current[0]) inputRefs.current[0].focus();
    
    // التحقق من وجود رسالة خطأ قادمة من عملية "طرد" من السيرفر
    const savedError = localStorage.getItem('login_error');
    if (savedError) {
        setError(savedError);
        localStorage.removeItem('login_error'); // مسح الرسالة حتى لا تظهر مرة أخرى عند التحديث
    } else if (externalError) {
        setError(externalError);
    }
  }, [externalError]);

  const handleChange = (index: number, value: string) => {
    const char = value.replace(/\D/g, '').substring(value.length - 1);
    if (value && !char) return;

    const newCodeParts = [...codeParts];
    newCodeParts[index] = char;
    setCodeParts(newCodeParts);
    
    if (char && index < 6) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !codeParts[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const fullCode = codeParts.join('');
    if (fullCode.length < 7) return;
    
    setIsLoading(true);
    setError(null);
    try {
      const response = await API.verifyCode(fullCode);
      if (response.success) {
        onLogin(response.student);
      } else {
        setError(response.message);
      }
    } catch (err: any) {
      setError('خطأ في الاتصال بالسيرفر');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (codeParts.join('').length === 7) handleSubmit();
  }, [codeParts]);

  return (
    <div className="min-h-screen bg-[#050511] flex flex-col items-center justify-center p-6 relative font-['Tajawal'] overflow-hidden">
      
      {/* Moving Background Blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-purple-600/40 rounded-full blur-[120px] mix-blend-screen animate-blob"></div>
        <div className="absolute top-[20%] right-[-10%] w-[500px] h-[500px] bg-cyan-500/30 rounded-full blur-[120px] mix-blend-screen animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-[-10%] left-[20%] w-[600px] h-[600px] bg-pink-600/30 rounded-full blur-[120px] mix-blend-screen animate-blob animation-delay-4000"></div>
        
        {/* Subtle Grid Overlay */}
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-150"></div>
      </div>

      <div className="w-full max-w-[420px] relative z-20">
        
        {/* Animated Logo Section */}
        <div className="text-center mb-10 animate__animated animate__fadeInDown relative group cursor-default">
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-purple-600 blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity duration-1000"></div>
          
          <div className="relative inline-block mb-6">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 rounded-[2rem] blur opacity-75 animate-pulse"></div>
            <div className="relative w-24 h-24 bg-[#0a0a16] border border-white/10 rounded-[2rem] flex items-center justify-center shadow-2xl backdrop-blur-xl group-hover:scale-105 transition-transform duration-500">
               <span className="text-5xl bg-clip-text text-transparent bg-gradient-to-br from-cyan-400 to-purple-500 filter drop-shadow">⚡</span>
            </div>
          </div>

          <h1 className="text-5xl font-black text-white tracking-tighter mb-2 drop-shadow-lg">
            كورسات <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">بلس</span>
          </h1>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.4em]">Future Learning Platform</p>
        </div>

        {/* Glass Card */}
        <div className={`bg-white/5 backdrop-blur-2xl rounded-[3rem] p-8 border border-white/10 shadow-[0_0_50px_-12px_rgba(0,0,0,0.5)] animate__animated animate__fadeInUp ${error ? 'animate__shakeX ring-2 ring-red-500/50' : ''}`}>
          
          <div className="text-center mb-8">
            <h2 className="text-xl font-black text-white mb-2">تسجيل الدخول</h2>
            <p className="text-slate-400 text-xs font-medium">أدخل الكود الشخصي للوصول إلى المحتوى</p>
          </div>

          {/* Inputs Grid */}
          <div className="flex gap-2 justify-center mb-10" dir="ltr">
            {codeParts.map((digit, idx) => (
              <div key={idx} className="relative group">
                 <div className={`absolute -inset-0.5 bg-gradient-to-b from-cyan-500 to-purple-600 rounded-2xl blur opacity-0 transition duration-500 ${digit || idx === codeParts.findIndex(x => !x) ? 'opacity-75' : 'group-hover:opacity-50'}`}></div>
                 <input
                  ref={(el) => { inputRefs.current[idx] = el; }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleChange(idx, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(idx, e)}
                  className={`relative w-11 h-16 rounded-xl text-center text-2xl font-black transition-all duration-200 outline-none
                    ${digit 
                      ? 'bg-[#0f1021] text-white shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]' 
                      : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }
                    focus:bg-[#0f1021] focus:text-cyan-400 focus:scale-110
                  `}
                />
              </div>
            ))}
          </div>

          {error && (
            <div className="bg-red-500/10 backdrop-blur-md border border-red-500/20 text-red-400 text-[11px] font-bold text-center py-4 rounded-2xl mb-6 flex items-center justify-center gap-2 animate__animated animate__pulse">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
              {error}
            </div>
          )}

          {/* Glowing Button */}
          <button 
            onClick={() => handleSubmit()}
            disabled={isLoading}
            className="group relative w-full h-16 rounded-[2rem] overflow-hidden disabled:opacity-70 transition-all active:scale-95"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 transition-all duration-300 group-hover:scale-110"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-in-out"></div>
            
            <div className="relative flex items-center justify-center gap-3 h-full">
              {isLoading ? (
                <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <span className="text-white font-black text-lg tracking-wide group-hover:tracking-wider transition-all">تفعيل الحساب</span>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white group-hover:translate-x-[-5px] transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M11 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                </>
              )}
            </div>
          </button>
          
          {/* Subscribe Link Section */}
          <div className="mt-10 text-center animate__animated animate__fadeIn animate__delay-1s">
             <p className="text-slate-400 font-bold text-sm">
               عايز تشترك؟ 
               <button 
                 onClick={() => navigate('/how-to-subscribe')}
                 className="mr-2 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 hover:to-purple-400 font-black border-b border-blue-500/30 transition-all active:scale-95"
               >
                 دوس هنا واعرف الخطوات
               </button>
             </p>
          </div>
          
          <div className="mt-8 text-center">
             <div className="h-px w-20 bg-gradient-to-r from-transparent via-white/10 to-transparent mx-auto mb-3"></div>
             <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest opacity-60">Secure Access v2.0</p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
};

export default Login;
