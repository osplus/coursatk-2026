
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import { API } from '../services/api';
import { Lecture, Announcement } from '../types';

interface NotificationsProps {
  student?: any;
}

const Notifications: React.FC<NotificationsProps> = ({ student }) => {
  const navigate = useNavigate();
  const [items, setItems] = useState<(Lecture | Announcement)[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeLeft, setTimeLeft] = useState<{ d: number, h: number, m: number, s: number } | null>(null);

  // منطق المؤقت (العد التنازلي)
  useEffect(() => {
    if (!student?.expiryDate) return;

    const calculateTime = () => {
      const diff = new Date(student.expiryDate).getTime() - new Date().getTime();
      if (diff <= 0) {
        setTimeLeft(null);
      } else {
        setTimeLeft({
          d: Math.floor(diff / (1000 * 60 * 60 * 24)),
          h: Math.floor((diff / (1000 * 60 * 60)) % 24),
          m: Math.floor((diff / 1000 / 60) % 60),
          s: Math.floor((diff / 1000) % 60)
        });
      }
    };

    calculateTime();
    const timer = setInterval(calculateTime, 1000);
    return () => clearInterval(timer);
  }, [student?.expiryDate]);

  // جلب البيانات
  const fetchUpdates = async () => {
    try {
      const [lecturesData, announcementsData] = await Promise.all([
        API.getRecentLectures(10),
        API.getAnnouncements()
      ]);
      
      const lectures = Array.isArray(lecturesData) ? lecturesData : [];
      const announcements = Array.isArray(announcementsData) ? announcementsData : [];

      // دمج وترتيب العناصر
      const mixedItems = [...lectures, ...announcements].sort((a, b) => {
        const getTimestamp = (item: any) => {
           const dateStr = item.createdAt || item.date;
           if (!dateStr) return 0;
           const time = new Date(dateStr).getTime();
           return isNaN(time) ? 0 : time;
        };
        return getTimestamp(b) - getTimestamp(a); // الأحدث أولاً
      });

      setItems(mixedItems);
    } catch (err) {
      console.error("Failed to fetch notifications:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUpdates();
    const refreshInterval = setInterval(fetchUpdates, 30000); // تحديث كل 30 ثانية
    return () => clearInterval(refreshInterval);
  }, []);

  const handleNoticeClick = (item: any) => {
    navigate(`/lecture/${item.id}`);
  };

  const handleAnnouncementClick = (link?: string) => {
    if (!link) return;
    if (link.startsWith('http')) {
        window.open(link, '_blank');
    } else {
        navigate(link);
    }
  };

  const isAnnouncement = (item: any): item is Announcement => {
    return (item as Announcement).message !== undefined;
  };

  // التحقق هل العنصر جديد (آخر 48 ساعة)
  const isNewItem = (dateString?: string) => {
    if (!dateString) return false;
    const now = new Date().getTime();
    const itemDate = new Date(dateString).getTime();
    if (isNaN(itemDate)) return false;
    const diffHours = (now - itemDate) / (1000 * 60 * 60);
    return diffHours < 48;
  };

  return (
    <div className="min-h-screen bg-slate-950 dark:bg-[#020617] pb-36 relative overflow-x-hidden font-['Tajawal'] text-white transition-colors duration-300" dir="rtl">
      
      {/* خلفية حية متحركة */}
      <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-purple-600/20 blur-[150px] rounded-full animate-pulse"></div>
          <div className="absolute bottom-[-10%] left-[-20%] w-[500px] h-[500px] bg-blue-600/20 blur-[150px] rounded-full" style={{ animationDelay: '2s' }}></div>
          <div className="absolute top-[40%] left-[20%] w-[300px] h-[300px] bg-pink-500/10 blur-[100px] rounded-full animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      <div className="px-6 pt-16 relative z-10">
        <div className="flex justify-between items-end mb-10">
            <div className="animate__animated animate__fadeInRight">
                <h1 className="text-4xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400 drop-shadow-lg">
                  مركز <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">التنبيهات</span>
                </h1>
                <p className="text-xs text-slate-400 font-bold tracking-widest uppercase">كل ما يهمك في مكان واحد</p>
            </div>
            
            <button 
                onClick={() => { setIsLoading(true); fetchUpdates(); }}
                className="w-12 h-12 rounded-2xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white backdrop-blur-md border border-white/10 shadow-lg active:scale-90 transition-all group"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 group-hover:rotate-180 transition-transform duration-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
            </button>
        </div>

        <div className="space-y-5">
          {/* عداد الوقت بتصميم جديد */}
          {student?.expiryDate && (
            <div className={`relative p-6 rounded-[2.5rem] overflow-hidden transition-all animate__animated animate__fadeInDown ${timeLeft ? 'bg-slate-900/40 border border-orange-500/30' : 'bg-red-950/30 border border-red-500/30'}`}>
              <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent pointer-events-none"></div>
              {timeLeft && <div className="absolute -top-10 -right-10 w-32 h-32 bg-orange-500/20 blur-2xl rounded-full"></div>}
              
              <div className="flex flex-col md:flex-row gap-5 items-center relative z-10">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shrink-0 border shadow-[0_0_20px_rgba(0,0,0,0.3)] backdrop-blur-sm ${timeLeft ? 'bg-gradient-to-br from-orange-500/20 to-amber-600/20 border-orange-500/40 text-orange-400' : 'bg-red-500/20 border-red-500/40 text-red-500'}`}>
                  {timeLeft ? '⏳' : '🔒'}
                </div>
                
                <div className="flex-1 text-center md:text-right w-full">
                  <h3 className="font-black text-white mb-3 text-sm flex items-center justify-center md:justify-start gap-2">
                    {timeLeft ? (
                      <>
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                        الوقت المتبقي لاشتراكك
                      </>
                    ) : 'انتهت صلاحية الاشتراك'}
                  </h3>
                  
                  {timeLeft ? (
                    <div className="grid grid-cols-4 gap-2" dir="ltr">
                      {[
                        { label: 'Days', val: timeLeft.d },
                        { label: 'Hours', val: timeLeft.h },
                        { label: 'Mins', val: timeLeft.m },
                        { label: 'Secs', val: timeLeft.s }
                      ].map((t, i) => (
                        <div key={i} className="bg-black/30 rounded-xl py-2 px-1 text-center border border-white/5 backdrop-blur-md">
                          <div className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400 font-mono">{String(t.val).padStart(2, '0')}</div>
                          <div className="text-[7px] text-slate-500 font-bold uppercase tracking-wider">{t.label}</div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-red-300 text-xs font-bold text-center">
                      يرجى التواصل مع الدعم الفني لتجديد الاشتراك
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {isLoading ? (
            <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/5 animate-pulse text-center flex flex-col items-center justify-center h-48">
               <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4 shadow-[0_0_15px_rgba(59,130,246,0.5)]"></div>
               <span className="text-sm font-bold text-slate-400">جاري تحديث البيانات...</span>
            </div>
          ) : (
            (items || []).map((item, idx) => {
               const isNew = isNewItem(isAnnouncement(item) ? item.date : item.createdAt);
               const delay = idx * 100;

               if (isAnnouncement(item)) {
                 const isAlert = item.type === 'alert';
                 const hasLink = !!item.link;
                 return (
                    <div 
                      key={`ann-${item.id}`}
                      onClick={() => handleAnnouncementClick(item.link)}
                      className={`relative p-6 rounded-[2.5rem] border flex gap-5 animate-slideUp group overflow-hidden transition-all duration-300 shadow-lg hover:scale-[1.01]
                        ${isAlert 
                            ? 'bg-gradient-to-br from-red-950/40 to-rose-900/10 border-red-500/30 hover:border-red-500/50' 
                            : 'bg-gradient-to-br from-slate-900/60 to-slate-800/40 border-white/10 hover:border-purple-500/30'}
                        ${hasLink ? 'cursor-pointer' : ''}
                      `}
                      style={{ animationDelay: `${delay}ms` }}
                    >
                      {/* تأثير جانبي */}
                      <div className={`absolute top-0 right-0 w-1 h-full ${isAlert ? 'bg-red-500' : 'bg-purple-500'}`}></div>

                      {isNew && (
                          <div className="absolute top-4 left-4 z-10">
                              <span className="relative flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500"></span>
                              </span>
                          </div>
                      )}
                      
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0 border backdrop-blur-md shadow-inner
                          ${isAlert 
                            ? 'bg-red-500/10 border-red-500/30 text-red-500 shadow-red-900/20' 
                            : 'bg-purple-500/10 border-purple-500/30 text-purple-400 shadow-purple-900/20'}
                      `}>
                        {isAlert ? '📢' : '💡'}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className={`font-black text-base truncate ml-2 ${isAlert ? 'text-red-400' : 'text-purple-300'}`}>{item.title}</h3>
                          <span className="text-[9px] font-black text-slate-500 bg-black/20 px-2 py-0.5 rounded-lg border border-white/5 whitespace-nowrap">تنبيه إداري</span>
                        </div>
                        
                        <p className="text-slate-300 text-xs font-medium leading-relaxed opacity-90">{item.message}</p>
                        
                        {hasLink && (
                          <div className="mt-4 inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-blue-400 hover:text-blue-300 transition-colors bg-blue-500/5 px-3 py-1.5 rounded-xl border border-blue-500/10 hover:border-blue-500/30">
                            <span>فتح الرابط المرفق</span>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 group-hover:translate-x-[-3px] transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                          </div>
                        )}
                      </div>
                    </div>
                 );
               } else {
                 const lecture = item as Lecture;
                 return (
                    <div 
                      key={`lec-${lecture.id}`}
                      onClick={() => handleNoticeClick(lecture)}
                      className="group relative bg-gradient-to-br from-[#1e293b]/80 to-[#0f172a]/90 backdrop-blur-xl p-5 rounded-[2.5rem] border border-white/5 shadow-xl flex gap-5 cursor-pointer overflow-hidden hover:border-blue-500/30 transition-all duration-300 hover:scale-[1.01] animate-slideUp"
                      style={{ animationDelay: `${delay}ms` }}
                    >
                      {/* Glow Effect on Hover */}
                      <div className="absolute inset-0 bg-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none blur-xl"></div>
                      
                      {isNew && (
                         <div className="absolute top-0 left-0 bg-blue-600 text-white text-[9px] font-black px-3 py-1 rounded-br-xl shadow-[0_0_15px_rgba(37,99,235,0.5)] z-20">
                             جديد
                         </div>
                      )}

                      <div className="relative w-20 h-20 rounded-2xl overflow-hidden shrink-0 border border-white/10 shadow-lg group-hover:shadow-blue-900/20 transition-all group-hover:scale-105">
                         {lecture.thumbnail ? (
                            <img src={lecture.thumbnail} alt="" className="w-full h-full object-cover" />
                         ) : (
                            <div className="w-full h-full bg-slate-800 flex items-center justify-center text-3xl">🎬</div>
                         )}
                         <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
                         <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                             <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                                 <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 001-1.664l-3-2z" clipRule="evenodd" /></svg>
                             </div>
                         </div>
                      </div>

                      <div className="flex-1 flex flex-col justify-center relative z-10">
                        <div className="flex justify-between items-center mb-1">
                             <span className="text-[9px] font-black text-blue-400 uppercase tracking-wider">محاضرة جديدة</span>
                             <span className="text-[9px] text-slate-500 font-bold">{new Date(lecture.createdAt || '').toLocaleDateString('ar-EG')}</span>
                        </div>
                        <h3 className="font-black text-white text-base leading-snug mb-2 line-clamp-1 group-hover:text-blue-400 transition-colors">{lecture.title}</h3>
                        <div className="flex items-center gap-2">
                             <div className="h-1 flex-1 bg-slate-700/50 rounded-full overflow-hidden">
                                 <div className="h-full bg-blue-500 w-1/3"></div>
                             </div>
                             <span className="text-[9px] text-slate-400 font-bold">شاهد الآن</span>
                        </div>
                      </div>
                    </div>
                 );
               }
            })
          )}

          {!isLoading && (!items || items.length === 0) && (
            <div className="py-24 text-center opacity-50 animate__animated animate__fadeInUp relative">
               <div className="absolute inset-0 bg-gradient-to-t from-transparent via-blue-500/5 to-transparent blur-xl"></div>
               <div className="relative z-10">
                  <div className="text-6xl mb-4 grayscale opacity-30 drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">🌌</div>
                  <h3 className="font-black text-lg text-white mb-1">هدوء تام...</h3>
                  <p className="font-medium text-sm text-slate-400">لا توجد تحديثات جديدة في الوقت الحالي</p>
               </div>
            </div>
          )}
        </div>
      </div>
      <BottomNav />
      <style>{`
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .animate-slideUp { animation: slideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
    </div>
  );
};

export default Notifications;
