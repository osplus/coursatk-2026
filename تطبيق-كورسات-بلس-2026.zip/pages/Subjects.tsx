
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { API } from '../services/api';
import BottomNav from '../components/BottomNav';
import { Subject } from '../types';

interface SubjectsProps {
  student?: any;
}

const Subjects: React.FC<SubjectsProps> = ({ student }) => {
  const [allSubjects, setAllSubjects] = useState<Subject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    const isDark = document.documentElement.classList.contains('dark');
    setIsDarkMode(isDark);

    const fetch = async () => {
      try {
        const data = await API.getSubjects();
        setAllSubjects(data);
      } catch (err) { console.error(err); }
      finally { setIsLoading(false); }
    };
    fetch();
  }, []);

  const toggleTheme = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDarkMode(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#020617] pb-56 relative overflow-hidden transition-colors duration-300">
      {/* Background Decorative Glow */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none"></div>
      
      {/* Header Section */}
      <div className="px-6 pt-16 mb-8 relative z-10">
        <div className="flex items-center justify-between mb-10 animate__animated animate__fadeInDown">
          <Link to="/profile" className="flex items-center gap-4 group">
             <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-75 transition duration-1000"></div>
                <div className="relative w-14 h-14 rounded-2xl bg-white dark:bg-[#0f172a] flex items-center justify-center border border-slate-200 dark:border-white/10 shadow-2xl transition-transform group-hover:rotate-6">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                   </svg>
                </div>
             </div>
             <div>
                <p className="text-blue-500 dark:text-blue-400 text-[9px] font-black uppercase tracking-[0.3em] mb-0.5">مرحباً بك</p>
                <h1 className="text-lg font-black text-slate-800 dark:text-premium leading-none">{student?.name || 'طالب متميز'}</h1>
             </div>
          </Link>
          
          <div className="flex items-center gap-3">
             <button 
                onClick={toggleTheme}
                className="w-12 h-12 bg-white dark:bg-white/5 backdrop-blur-md rounded-2xl flex items-center justify-center border border-slate-200 dark:border-white/10 shadow-lg active:scale-90 transition-all text-slate-500"
             >
                {isDarkMode ? <span className="text-xl">☀️</span> : <span className="text-xl">🌙</span>}
             </button>

             <Link to="/notifications" className="relative group">
                <div className="w-12 h-12 bg-white dark:bg-white/5 backdrop-blur-md rounded-2xl flex items-center justify-center relative border border-slate-200 dark:border-white/10 shadow-xl active:scale-90 transition-all">
                    <div className="absolute top-3 right-3 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-[#020617] animate-pulse"></div>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-500 dark:text-gray-400 group-hover:text-blue-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                </div>
             </Link>
          </div>
        </div>

        <div className="animate__animated animate__fadeInLeft" style={{ animationDelay: '0.2s' }}>
            <h2 className="text-4xl font-black text-slate-800 dark:text-white leading-[1.2] mb-2">استكشف <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-purple-600 dark:from-blue-400 dark:to-purple-500">موادك الدراسية</span></h2>
            <p className="text-slate-500 text-xs font-bold tracking-wide">اختر المادة لتبدأ رحلة التعلم الذكي</p>
        </div>
      </div>

      {/* Subjects Grid */}
      <div className="px-5 grid grid-cols-2 gap-5 relative z-10">
        {isLoading ? (
          [1, 2, 3, 4].map(i => (
            <div key={i} className="h-72 bg-slate-200 dark:bg-white/5 rounded-[3rem] animate-pulse"></div>
          ))
        ) : (
          allSubjects.map((subject, idx) => (
            <Link 
              key={subject.id} 
              to={`/subject/${subject.id}/teachers`}
              className="group glass-card rounded-[3rem] overflow-hidden border border-white/40 dark:border-white/5 shadow-xl dark:shadow-2xl animate-card hover:border-blue-500/30 transition-all duration-500"
              style={{ animationDelay: `${0.4 + (idx * 0.15)}s` }}
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                 <img src={subject.image} alt={subject.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000 ease-out" />
                 <div className="absolute inset-0 bg-gradient-to-t from-white/90 via-transparent to-transparent dark:from-[#020617] dark:via-transparent"></div>
                 <div className="absolute top-5 left-5 bg-white/90 dark:bg-blue-600/90 backdrop-blur-md px-3 py-1 rounded-xl text-[9px] font-black text-blue-600 dark:text-white shadow-xl animate-float">
                    {subject.lessonsCount || 0} محاضرة
                 </div>
              </div>
              <div className="p-6 text-right relative">
                <h3 className="text-lg font-black text-slate-800 dark:text-premium mb-4 group-hover:text-blue-500 transition-colors line-clamp-1">{subject.name}</h3>
                <div className="relative w-full py-3 bg-slate-100 dark:bg-[#1e293b] rounded-2xl text-center overflow-hidden group/btn">
                  <span className="relative z-10 text-slate-700 dark:text-white font-black text-[11px] uppercase tracking-wider group-hover/btn:text-white transition-colors">ابدأ الآن</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
      <BottomNav />
    </div>
  );
};

export default Subjects;
